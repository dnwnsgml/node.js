const express = require('express');
const fs = require('fs');   //파일관련패키지
const ejs = require('ejs'); //npm i ejs

const app = express();
const port = 3000;
const router = express.Router();

//127.0.0.1:3000/login
router.route('/login').post((req, res) => {
    const userinfo = { userid: 'apple', userpw: '1234' };
    fs.readFile('./ejs02.ejs', 'utf-8', (err, data) => {
        if (!err) {
            res.writeHead(200, { 'content-type': 'text/html' });
            res.end(ejs.render(data, userinfo));
            // ejs 파일을 렌더링하면서 특정데이터값(파라미터)을 전달
        } else {
            console.log(err);
        }
    });
});

app.use('/', router);

// 404가 발생하고 파일을 찾지 못했을때 보여줄 메시지
app.use('*', (req, res) => {
    res.status(404).send('<h2>페이지를 찾을 수 없습니다.</h2>');
})

app.listen(port, () => {
    console.log(`${port} 포트로 서버 실행중..`);
})