const express = require('express');
const app = express();
const port = 3000;

// get 방식으로 데이터 전송하는 함수
app.use((req, res) => {
    console.log('첫번째 미들웨어 실행');

    console.dir(req.header);    // 전달한다는 의미
    const userAgent = req.header('User-Agent');
    console.log(userAgent);

    //127.0.0.1:3000/?userid=apple
    const paramName = req.query.userid;  // get 방식의 변수값을 요청
    console.log(paramName);
    //paramName : 매개변수, 함수를 실행할때 보내는 값


    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
    res.write('<h2>익스프레스 서버에서 응답한 메세지입니다.</h2>');
    res.write(`<p>User-Agent : ${userAgent}</p>`);
    res.write(`<p>paramName : ${paramName}</p>`);
    res.end();  // res.write()을 사용할경우 res.end();작성문의 끝남을 의미
});

app.listen(port, () => {
    console.log(`${port} 포트로 서버실행중..`);
})