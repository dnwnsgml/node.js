const express = require('express');
const bodyParser = require('body-parser');  // post 데이터를 전달받기 위해 사용
const app = express();
const port = 3000;

const router = express.Router()

app.use(bodyParser.urlencoded({ extended: false }));

// post
router.route('/member/login').post((req, res) => {
    console.log('/member/login 호출 !');
});

// post
router.route('/member/regist').post((req, res) => {
    console.log('/member/regist 호출 !');
});

// get
router.route('/member/about').get((req, res) => {
    console.log('/member/about 호출 !');
});


//Router 정의 선언
app.use('/', router)



app.listen(port, () => {
    console.log(`${port} 포트로 서버실행중..`);
})